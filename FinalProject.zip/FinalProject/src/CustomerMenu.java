public class CustomerMenu {
    public static void run(String user) {
        System.out.println("Greetings, " + user + "!");
    }
}
